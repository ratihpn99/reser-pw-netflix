# netflixPassword
simple python script to automatically change your netflix password fast.
# How to Use
1- Download python 3 from here: https://www.python.org/downloads/ \
2- Install python 3 and make sure to check the box "ADD TO PATH " if you are using windows\
3- Check if python is installed correctly by typing pyhon3 on your CMD/TERMINAL\
4- Run python3 netflix.py\
5- Enjoy!
